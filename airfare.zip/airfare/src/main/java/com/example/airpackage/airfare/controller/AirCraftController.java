package com.example.airpackage.airfare.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.airpackage.airfare.service.AircraftService;

@RestController
@RequestMapping("/api/aircraft")
public class AirCraftController {

	@Autowired
	AircraftService aircraftService;
	
	@PostMapping("/offer")
	public void saveData(@RequestParam(value = "data", required = false) List<MultipartFile> file) throws IOException {
		aircraftService.allotDiscount(file.get(0));
	}
}
