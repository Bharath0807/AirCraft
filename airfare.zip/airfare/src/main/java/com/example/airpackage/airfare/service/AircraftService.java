package com.example.airpackage.airfare.service;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class AircraftService {

	public void allotDiscount(MultipartFile file) throws IOException {
		byte[] bytes = file.getBytes();

		ByteArrayInputStream inputFilestream = new ByteArrayInputStream(bytes);
		BufferedReader br = new BufferedReader(new InputStreamReader(inputFilestream));
		String line = "";
		String header = br.readLine();
		header += ",Error,Discount";
		PrintWriter writer = new PrintWriter(new File("src/main/resources/output.csv"));
		writer.write(header += "\n");
		while ((line = br.readLine()) != null) {
			System.out.println(line);
			String errorMessage = validate(line);
			String discountOffer = checkOffer(line);
			line += "," + errorMessage + "," + discountOffer;
			try {

				writer.write(line);
				writer.write("\n");
				System.out.println("done!");

			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			writer.close();
		}
	}

	private String checkOffer(String line) {
		String[] datas = line.split(",");
		String key = datas[3];
		int castAscii = (int) key.charAt(0);
		if (castAscii <= 69) {
			return "OFFER_20";
		} else if (castAscii <= 75) {
			return "OFFER_30";
		} else if (castAscii <= 82) {
			return "OFFER_25";
		} else if (castAscii <= 75) {
			return null;
		}
		return null;
	}

	String validate(String data) {

		StringBuilder error = new StringBuilder();
		String[] datas = data.split(",");
		validateEmail(datas[7], error);
		validatePnr(datas[2], error);
		validateMobilephone(datas[8], error);
		validateDate(datas[4], datas[6], error);
		validateEconomy(datas[9], error);
		if(error.length()>0) {
			return error.substring(0,error.length()-1);
		}
		return null;

	}

	private void validateDate(String travelDate, String ticketDate, StringBuilder error) {
		try {
			Date travelDate1 = new SimpleDateFormat("dd-MM-yyyy").parse(travelDate);
			Date ticketDate1 = new SimpleDateFormat("dd-MM-yyyy").parse(ticketDate);
			System.out.println(travelDate1);
			long diff = travelDate1.getTime() - ticketDate1.getTime();
			if(diff<0) {
				error.append("Travel data is greater than today;");
				System.out.println(error);
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void validateEmail(String email, StringBuilder error) {
		String regex = "^(.+)@(.+)$";

		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(email);
		if (!matcher.matches()) {
			error.append("Email is not valid;");
		}
	}

	private void validateMobilephone(String data, StringBuilder error) {
		try {
			if (data.length() == 10) {
				String regex = "\\d+";
				if(!data.matches(regex))
					error.append("Mobile number is not valid;");
			} else {
				error.append("Mobile number is not valid;");
			}
		} catch (Exception e) {
			error.append("Mobile number is not valid;");
		}
	}
	
	private void validateEconomy(String data, StringBuilder error) {
		List<String> list = new ArrayList<String>();
		list.add("Economy");
		list.add("Premium Economy");
		list.add("Business");
		list.add("First");
		
		if(list.indexOf(data) != -1) {
			error.append("Selected Economy is invalid;");
		}
	}

	private void validatePnr(String pnr, StringBuilder error) {
		String regex = "^(?=.*[a-zA-Z])(?=.*[0-9])[A-Za-z0-9]+$";

		Pattern p = Pattern.compile(regex);

		if (pnr == null || pnr.length() != 6) {
			error.append("Pnr: contains More than 6 character"
					+ ";");
			return;
		}

		Matcher m = p.matcher(pnr);

		if (!m.matches()) {
			error.append("Pnr: contains special characters;");
		}
	}

}
