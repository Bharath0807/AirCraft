package com.example.airpackage.airfare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirfareApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirfareApplication.class, args);
	}

}
