package com.example.airpackage.airfare;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest(classes = AirfareApplication.class)
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
public class AirfareApplicationTests {

	@Autowired
	private WebApplicationContext webApplicationContext;

	@Test
	public void validFile() throws Exception {

		File f = new File("src/main/resources/Input1.csv");
		MockMultipartFile file = new MockMultipartFile("data", "Input1.csv", "",
				FileUtils.readFileToString(f).getBytes());
		
		MockMvc mvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

		mvc.perform(MockMvcRequestBuilders.multipart("/api/aircraft/offer").file(file));
		
		f = new File("src/main/resources/output.csv");

		ByteArrayInputStream inputFilestream = new ByteArrayInputStream(FileUtils.readFileToString(f).getBytes());
		BufferedReader br = new BufferedReader(new InputStreamReader(inputFilestream));
		br.readLine();
		String[] content = br.readLine().split(",");
		assert content[content.length-1].contentEquals("OFFER_20");
		
		f = new File("src/main/resources/Wrong_data.csv");
		file = new MockMultipartFile("data", "Wrong_data.csv", "",
				FileUtils.readFileToString(f).getBytes());
		
		mvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

		mvc.perform(MockMvcRequestBuilders.multipart("/api/aircraft/offer").file(file));
		
		f = new File("src/main/resources/output.csv");

		
		inputFilestream = new ByteArrayInputStream(FileUtils.readFileToString(f).getBytes());
		br = new BufferedReader(new InputStreamReader(inputFilestream));
		br.readLine();
		content = br.readLine().split(",");
		
		assert content[content.length-1].contentEquals("OFFER_30");

	}

}
